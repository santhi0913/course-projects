package visitor;
import java.util.*;

public class classtable{
	public Hashtable <String, String> VarDec;
	public Hashtable <String, methodtable> MethDec;
	public String parent; 
}