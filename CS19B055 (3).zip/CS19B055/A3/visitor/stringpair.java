package visitor;

public class stringpair{
	public pair pp;
	public String ss;
}