package visitor;
import java.util.*;

public class listpair{
	public pair P;
	public LinkedList <String> LL;
}