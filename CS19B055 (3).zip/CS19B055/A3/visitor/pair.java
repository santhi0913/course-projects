package visitor;

public class pair{
	public String first;
	public String second;
}