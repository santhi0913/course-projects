package visitor;
import java.util.*;

public class classnewtable{
	public Hashtable <String, Integer> VarDec;
	public Hashtable <String, methodnewtable> MethDec;
	public String code;
	public Integer varcount;
	public Integer methcount; 
}