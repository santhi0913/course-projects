package visitor;
import java.util.*;

public class methodnewtable{
	public Integer args;
	public Integer index;
	public Integer varcount;
	public Hashtable <String, Integer> Params;
	public Hashtable <String, Integer> VarDec; 
}