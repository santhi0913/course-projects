package visitor;
import java.util.*;

public class myobject{
	public Hashtable <String, classtable> SymTab;
	public Hashtable <String, classnewtable> NewSymTab;
	public Integer count;
	public Integer labelcount;
}