package visitor;
import java.util.*;

public class methodtable{
	public String type;
	public LinkedHashMap <String, String> Params;
	public Hashtable <String, String> VarDec; 
}
